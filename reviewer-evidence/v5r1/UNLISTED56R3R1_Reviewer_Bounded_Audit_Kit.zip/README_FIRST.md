# UNLISTED56R3 — Reviewer Audit Kit (bounded, reproducible subset)

This kit is a **compact, non-field, publicly sourced evidence subset**, not the complete original EPSS source-byte archive and **not** a verified public DOI or reviewer-authorized URL. Manuscript outcome is later CISA KEV admission, not exploitation onset or attack prevention.

## Reproduce admitted fixed-cohort diagnostics

From the kit root, with Python 3.9+ and no third-party Python modules:

```bash
python replay/verify_review_kit.py
```

The script parses the actual primary 749-CVE observability certificate and companion official Git publication audit, recomputes the annual 2023–2026 stage partition and official-state totals, verifies the 174-date stored original source parity certificate, checks the 174-date original top-1000 workload totals and reads all archived RSS quotas, two different lag-clock interventions and 23 added CVE source classes. It independently recomputes these counts from released rows, and compares them with the locked figures.

## Data provenance and boundaries

* `Q1_749_CVE_30Day_Observability_Certificate.csv`, `event_timing_749.csv`, `policy_event_capture.csv`, `raw_q1_parity_gate.csv`, `workload_capture_summary.csv`, `input_manifest.csv`: extracted byte-for-byte from archived **UNLISTED49_Reproducibility_STANDALONE_VERIFIED.zip** (46,288,950 bytes); source SHA-256 in `SOURCE_LOCKS.json`. This is a frozen derived-outputs archive, not 174 uncompressed raw EPSS snapshots.
* `EXTRA_23_EVENT_ATTRIBUTION.csv`, `SOURCE_ADMISSION_78.csv`, `QUOTA_SENSITIVITY.csv`, `TWO_CLOCK_DELAY_SENSITIVITY.csv`, `POLICY_RESULTS.csv`, `R5_RESULT_LOCK.json`, `CLAIM_ADMISSIBILITY.csv`: extracted byte-for-byte from archived **UNLISTED55 R5 complete transfer ZIP** (24,300,894 bytes), previously run and evidence-gated.
* `KEV_AdmissionYear_StagePartition_749.csv`, `Official_Stage_By_AdmissionYear.csv`: recomputed 27 October 2026 from the original frozen 749 rows; no new outcome or decision policy has been applied.
* `SOURCE_LOCKS.json` records upstream hashes and this kit's exact dependencies; `SHA256_MANIFEST.json` records hash of each file in this kit excluding itself.

### What this kit does NOT establish

1. It **does not** re-download every original historical EPSS daily/weekly file and validate provider archive service timestamps. Full 174 dated Tuesday GZIP files reside in the separately verified **365,805,225-byte** UNLISTED49 source package restored from four files on Google Drive. A verified public reviewer-access link to that package is **not established**.
2. It **does not** independently re-acquire full historical raw GitHub GH Archive hour files; retained Git/event extracts do not certify original host delivery or perfect source coverage.
3. The RSS admission count reflects 59/60 effective content states after a separate initial-seed proof; the seed is not a tested decision, 8 Apr 2024 is HOLD, 9 Apr excluded. No 'not found' event is asserted never published.
4. Two +1 day lag definitions yield **22 (sample Monday) and 29 (public witness)**; neither is observed provider latency. Historical release time of Tuesday EPSS not established.
5. Four-week memory has more unique CVE selections. Equal shortlist slots are not equal manual review effort.
6. There is no prospective enterprise evidence or verified prevented attacks, no true time-of-first-exploitation outcome.

### Author/reviewer access gates

- The upstream source and original code exist in restricted Google Drive Project 1. This audit kit and manuscript can be given to a reviewer via a user-managed attachment or a repository release **after** rights and sharing checks.
- No public DOI, published dataset, publicly accessible reviewer URL, license for full raw redistribution, third-party reviewer permission, manuscript acceptance or journal submission is claimed.
- Any reviewer-specific Drive sharing would need an exact reviewer email or authorization by the user's Google Drive sharing UI; the connected Drive tool does not offer an unrestricted 'anyone with link' public-sharing action.

See `CLAIM_ADMISSIBILITY.csv` for explicit R5 KEEP/HOLD/REMOVE gates. No author identities, affiliations or contact metadata were added to the manuscript.
