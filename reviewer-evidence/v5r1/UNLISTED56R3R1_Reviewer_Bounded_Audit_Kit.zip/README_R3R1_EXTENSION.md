# UNLISTED56R3R1 — Bounded independent reviewer replay (derived input records)

Run from this folder with Python >=3.9:

    python RUN_ALL_REPLAYS.py

The command executes the inherited 749-record + annual split + official-state + 76-date RSS checks, then the original fail-closed 174-Tuesday/18,373-membership-row event-level 30-day reclassification. It recomputes 749/475/274/434/41 and earlier-only zero, plus four corrupted-input guard tests; it is not just a check against a published table. The reclassification inputs are **previously extracted, dated derived membership rows**, not the full historical EPSS source populations. No network or additional dependency is needed.

The source-derived inputs are retained from the previously verified UNLISTED49 archive, unchanged. The embedded R3 original SHA256_MANIFEST describes the inherited layer; this revision's separate `R3R1_EXTENSION_MANIFEST.json` covers added window replay files. A PASS is not original-source re-acquisition, historic GH Archive hourly custodial proof, or enterprise deployment verification. Do not claim all external reviewer access verified: rights and access gate remain HOLD.
