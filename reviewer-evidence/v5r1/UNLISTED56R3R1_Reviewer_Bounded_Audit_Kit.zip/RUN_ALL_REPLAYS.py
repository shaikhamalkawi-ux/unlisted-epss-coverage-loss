#!/usr/bin/env python3
import subprocess,sys,pathlib,json
root=pathlib.Path(__file__).resolve().parent
runs=[
 [sys.executable,'replay/verify_review_kit.py'],
 [sys.executable,'code/reproduce_30day_partition.py','--event-ledger','inputs/reported_public_event_input.csv','--decision-history','inputs/event_decision_history.csv.gz','--out-dir','outputs'],
 [sys.executable,'code/test_fail_closed.py'],
]
cwds=[root,root/'window_replay',root/'window_replay']
for i,(argv,cwd) in enumerate(zip(runs,cwds),start=1):
 print('RUN',i,' '.join(argv),'in',cwd,flush=True)
 p=subprocess.run(argv,cwd=cwd,check=False)
 if p.returncode:sys.exit(p.returncode)
summary=json.loads((root/'window_replay'/'outputs'/'Q1_30Day_Reclassification_Summary.json').read_text())
assert [summary[k] for k in ('cohort','ever_observed','never_observed','window_observed_not_selected_top1000','window_observed_and_selected_top1000','earlier_only_outside_window')]==[749,475,274,434,41,0]
print('ALL R3R1 BOUNDED REPLAYS PASS; ORIGINAL RAW-SOURCE/ACCESS NOT CERTIFIED',flush=True)
