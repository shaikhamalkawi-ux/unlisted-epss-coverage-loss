#!/usr/bin/env python3
"""Source-linked manuscript subsection checks, pure standard library. No field validation."""
from pathlib import Path
import csv, collections,json,hashlib,sys
p=Path(__file__).resolve().parents[1];f=p/'data'
def read(name):
 with (f/name).open(newline='',encoding='utf-8-sig') as r: return list(csv.DictReader(r))
def check(x,expected,label):
 if x!=expected: raise AssertionError(f'{label}: got {x}, expected {expected}')
 print('PASS',label,x)
rows=read('Q1_749_CVE_30Day_Observability_Certificate.csv')
check(len(rows),749,'original later KEV records')
check(len({x['cve'] for x in rows}),749,'unique CVE identifiers')
summary={}
for r in rows:
 year=r['kev_admission_date'][:4];o=summary.setdefault(year,collections.Counter());o['total']+=1
 cat=r['primary_category']
 if cat=='never_before_admission':o['missing']+=1
 elif cat=='observed_within_30_days_not_selected':o['missed']+=1
 elif cat=='observed_within_30_days_and_selected':o['selected']+=1
 else:raise AssertionError('Unexpected primary category '+repr(cat))
expected={'2023':[165,69,85,11],'2024':[186,67,110,9],'2025':[245,88,143,14],'2026':[153,50,96,7]}
for y,v in expected.items():check([summary[y][k] for k in ('total','missing','missed','selected')],v,'year '+y)
check([sum(summary[y][k] for y in expected) for k in ('total','missing','missed','selected')],[749,274,434,41],'whole cohort partition')
check(len(read('event_timing_749.csv')),749,'official-state timing ledger rows')
st=collections.Counter(x['official_stage_status'] for x in read('event_timing_749.csv'))
check(sum(n for s,n in st.items() if s.startswith('PUBLISHED_STATE_PRECEDES')),472,'confirmed prior published state')
check(st.get('HOLD_SAME_DAY_DECISION_ORDER',0),26,'unresolved intraday ordering incl observable cases')
check(749-472-26,251,'without prior confirmed state in full cohort')
source=read('raw_q1_parity_gate.csv')
check(len(source),174,'Q1 archived decision-date source parity rows')
check(all(x['all_original_ranks_scores_counts_match']=='True' for x in source),True,'archived Q1 rank and count parity')
work=read('workload_capture_summary.csv')
w=next(x for x in work if x['policy']=='repeated' and x['capacity']=='1000')
check([w['dates'],w['distinct_selected_cves'],w['captured_within_30_days']],['174','2981','41'],'171/174 support distinguished: original full 174 baseline')
q=read('QUOTA_SENSITIVITY.csv')
check([(int(x['quota']),int(x['captures']),int(x['unique_selected']),int(x['substitutions'])) for x in q],[(1,24,1560,67),(5,35,1602,216),(10,35,1613,305),(25,39,1626,403),(50,39,1633,450)],'R5 archived RSS fixed expiry quota sensitivity')
rss=read('EXTRA_23_EVENT_ATTRIBUTION.csv')
check(len(rss),23,'extra RSS distinct later KEV events')
check(sum(x['epss_present'].lower()=='false' for x in rss),7,'additional RSS captures EPSS-absent at first capture')
check(sum(x['epss_present'].lower()=='true' for x in rss),16,'additional RSS captures EPSS-below-cutoff at first capture')
lag=read('TWO_CLOCK_DELAY_SENSITIVITY.csv')
clockmap={(x['clock'],int(x['delay_days'])):int(x['captures']) for x in lag}
check(clockmap[('sample',1)],22,'sample-clock assumed +1 day capture')
# inspect clock string and adjust expected alias if necessary
public_names=[k for k in clockmap if k[1]==1 and k[0]!='sample']
check(len(public_names),1,'one independent non-sample clock')
check(clockmap[public_names[0]],29,'public-witness-clock assumed +1 day capture')
checks=json.loads((p/'SOURCE_LOCKS.json').read_text())
check(checks['source_primary_sha256']!='',True,'primary source provenance recorded')
print('ALL ADMITTED BOUNDED REPLAY CHECKS PASS')
