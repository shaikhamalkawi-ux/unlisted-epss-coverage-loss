# UNLISTED48 — Window-matched observability audit (reproducible derived records)

This is an **offline, deterministic** reclassification of the frozen Q1/KEV case ledger against the corresponding dated CVE-by-Tuesday decision history. It addresses the editorial concern that previous source observability at any earlier date might not imply availability within the last 30 days.

**Result:** `N=749`, `N_O=475`, `N_O,30=475`, earlier-only `0`, never observed `274`, within-30-days observed but Top-1000-unselected `434`, within-30-days Top-1000-selected `41`. In the 434 unselected events, `424` have a complete eligible Tuesday calendar within their final 30-day window and `309` of those occurred at every such Tuesday; the proportion `309/434=71.20%` is calculated against all observable noncaptures, not merely complete-window cases.

## Reproduce (Python 3 standard library, offline)

```sh
python code/reproduce_30day_partition.py \
  --event-ledger inputs/reported_public_event_input.csv \
  --decision-history inputs/event_decision_history.csv.gz \
  --out-dir outputs
python code/test_fail_closed.py
```

The deterministic CSV output has one row per outcome CVE and fields for `ever_observed`, `observed_within_30_days`, `earlier_only`, `selected_top1000_within_30_days`, the schedule/window completeness and source history lead-time bounds. The test detects source/horizon mismatches, duplicate CVEs, missing membership and ranking provenance, and tampered event-level flags. No missing daily values are imputed.

## Source provenance (derived data, not upstream raw archive)

- `inputs/event_decision_history.csv.gz` originated in `VULN_PU_UNLISTED_Unlisted14_Full_Reproducibility_Archive_RECOVERED_VERIFIED.zip` → `LOCKED_BASELINE_REPRODUCIBILITY/Unlisted12_Tables_Audits_Code/locked_results/prospective_evaluation/event_decision_history.csv.gz`.
- `inputs/reported_public_event_input.csv` originated in `UNLISTED40_CSA_Supplementary_Material_2_Stagewise_Coverage_Reproducibility_v1.1.1.zip` → `Additional_File_2_Stagewise_Coverage_Reproducibility_Package/reported_public_event_input.csv`.
- The latter provides the accepted 749-event event-level field mapping, and the former provides 18,373 dated **observed-event membership** rows spanning 174 Tuesdays (7 March 2023 to 30 June 2026). Source-file hashes are in `outputs/Q1_30Day_Reclassification_Summary.json` and `SHA256_MANIFEST.csv`.
- Third-party source of original score populations: FIRST EPSS, https://www.first.org/epss/data and https://github.com/empiricalsec/epss_scores ; outcome: CISA KEV. This archive contains **derived** project records, not the complete historical raw scores or the cvelistV5 source cache.

## Interpretation boundaries

- This replay establishes 30-day Tuesday-source membership *for the frozen Q1 case ledger*. It does **not** rerun acquisition of all 174 full EPSS candidate files from their original remote hosts. That upstream reconstruction is separately documented in prior preservation archives.
- Earlier-only noncaptures could occur in other schedules, sources or cohorts; they happen to equal zero in this one.
- A CVE observed at least once within 30 days need not have been available on all four or five scheduled Tuesdays, nor continuously on all daily snapshots.
- The 434 source-available, unselected CVEs are **not** causally attributable solely to Top-1000 budget; their ranks, temporal coverage, tie rules and deployment-specific applicability matter.
- Future CISA KEV admission is a catalogue outcome, not a direct exploitation onset, vulnerability field prevalence or remediation action.
- Third-party data terms persist; inclusion of derived input rows here does not relicense external raw EPSS/KEV feeds.
