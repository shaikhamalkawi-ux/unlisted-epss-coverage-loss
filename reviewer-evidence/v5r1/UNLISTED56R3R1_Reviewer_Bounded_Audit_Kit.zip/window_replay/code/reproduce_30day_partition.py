#!/usr/bin/env python3
"""Fail-closed replay of Q1 pre-KEV Tuesday observability and 30-day Top-1000 coverage.

Inputs are derived, version-pinned historical event ledgers; this code does not
fetch third-party raw EPSS populations or relabel the future KEV admission target.
Python 3 standard library only; file hashes and count consistency are checked.
"""
from __future__ import annotations
import argparse, csv, datetime as dt, gzip, hashlib, json, pathlib, collections

DATE_FMT = '%Y-%m-%d'
ORIGIN = dt.date(2023,3,7)
LAST = dt.date(2026,6,30)
WINDOW_DAYS = 30
RANK = 1000


def stream_hash(p):
    sha = hashlib.sha256()
    with open(p,'rb') as fd:
        for block in iter(lambda: fd.read(1048576), b''):
            sha.update(block)
    return sha.hexdigest()

def fail(cond, message):
    if not cond:
        raise RuntimeError('FAIL-CLOSED: '+message)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--event-ledger', required=True)
    p.add_argument('--decision-history', required=True)
    p.add_argument('--out-dir', required=True)
    args = p.parse_args()
    out=pathlib.Path(args.out_dir);out.mkdir(parents=True, exist_ok=True)
    cohort=[]
    with open(args.event_ledger, newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            fail(row.get('outcome_id'), 'missing CVE ID')
            cohort.append(row)
    ids=[r['outcome_id'] for r in cohort]
    fail(len(ids)==749,'cohort is not 749 admissions')
    fail(len(set(ids))==len(ids),'duplicate outcome ID')
    fail(set(r.get('source_observable') for r in cohort) <= {'True','False','true','false','1','0'},'invalid source-observable encoding')
    cohort_dates={r['outcome_id']: r['future_outcome_date'] for r in cohort}
    rows=collections.defaultdict(list);times=set();duplicates=set();n=0
    with gzip.open(args.decision_history,'rt',newline='',encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            n+=1; cv=row['cve'];fail(cv in ids,'history contains CVE outside frozen cohort: '+cv)
            date=dt.date.fromisoformat(row['decision_date']); kev=dt.date.fromisoformat(row['kev_date_added'])
            lead=(kev-date).days
            fail(date.weekday()==1, 'non-Tuesday history row')
            fail(ORIGIN<=date<=LAST, 'decision outside locked Tuesday span')
            fail(lead>0 and lead==int(row['lead_days']), 'non-prior or invalid lead days')
            fail(kev.isoformat()==cohort_dates[cv], 'KEV date mismatch')
            key=(cv,date)
            fail(key not in duplicates,'duplicate CVE decision-date pair')
            duplicates.add(key);times.add(date)
            rmin=int(row['epss_rank_min']);rmax=int(row['epss_rank_max']); cand=int(row['candidate_count'])
            fail(1<=rmin<=rmax<=cand, 'rank range outside candidate population')
            rows[cv].append((date,lead,rmin,rmax))
    all_tuesdays=set()
    t=ORIGIN
    while t<=LAST:
        all_tuesdays.add(t); t+=dt.timedelta(days=7)
    fail(len(all_tuesdays)==174,'unexpected Tuesday schedule length')
    fail(times==all_tuesdays,'history has incomplete dated source support')
    output=[];obs30_ids=set();ever_ids=set();top_ids=set();full_noncap=0;always_noncap=0
    for row in cohort:
        cv=row['outcome_id']; date=dt.date.fromisoformat(row['future_outcome_date']);history=rows[cv]
        ever=bool(history); in30=[x for x in history if 0<x[1]<=WINDOW_DAYS]; obs30=bool(in30)
        selected=any(x[3] <= RANK for x in in30)
        rank_raw=row['best_conservative_rank_within_horizon'].strip()
        documented_selected= bool(rank_raw) and float(rank_raw)<=RANK
        fail(selected==documented_selected, 'Top-1000 locked input versus dated history discrepancy: '+cv)
        documented_observed=row['source_observable'].strip().lower() in {'true','1'}
        fail(ever==documented_observed, 'ever-observable locked input discrepancy: '+cv)
        if ever: ever_ids.add(cv)
        if obs30: obs30_ids.add(cv)
        if selected: top_ids.add(cv)
        expected=set();t=ORIGIN
        # All Tuesday days strictly before admission and no more than 30 days prior,
        # including expected dates that pre-date the study opening or post-date its end.
        monday = date - dt.timedelta(days=WINDOW_DAYS)
        shift=(1-monday.weekday())%7
        t=monday+dt.timedelta(days=shift)
        while t<date:
            expected.add(t);t+=dt.timedelta(days=7)
        complete=bool(expected) and expected.issubset(all_tuesdays)
        observed_tuesdays={x[0] for x in in30}
        all_weekly=complete and observed_tuesdays==expected
        if ever and not selected and complete:
            full_noncap+=1
            if all_weekly:always_noncap+=1
        category=('never_before_admission' if not ever else
                  'earlier_only_absent_in_last_30_days' if not obs30 else
                  'observed_within_30_days_and_selected' if selected else
                  'observed_within_30_days_not_selected')
        output.append(dict(cve=cv,kev_admission_date=date,primary_category=category,
                           ever_observed=int(ever),observed_within_30_days=int(obs30),
                           earlier_only=int(ever and not obs30),selected_top1000_within_30_days=int(selected),
                           eligible_tuesdays_last_30=len(expected),
                           observed_tuesdays_last_30=len(observed_tuesdays),
                           complete_30_day_window=int(complete),
                           observed_at_every_eligible_tuesday=int(all_weekly),
                           earliest_observed_lead_days=max((x[1] for x in history),default=''),
                           nearest_observed_lead_days=min((x[1] for x in history),default='')))
    counts=collections.Counter(v['primary_category'] for v in output)
    exp=dict(never_before_admission=274,earlier_only_absent_in_last_30_days=0,
             observed_within_30_days_not_selected=434,observed_within_30_days_and_selected=41)
    fail(all(counts.get(k,0)==v for k,v in exp.items()) and sum(counts.values())==749, f'partition drift: {counts}')
    fail(len(ever_ids)==475 and len(obs30_ids)==475 and len(top_ids)==41,'expected ever/30-day selection count mismatch')
    fail(full_noncap==424 and always_noncap==309,'persistent noncaptured eligible-window check differs')
    with (out/'Q1_749_CVE_30Day_Observability_Certificate.csv').open('w',newline='',encoding='utf-8') as fd:
        wr=csv.DictWriter(fd,fieldnames=output[0].keys());wr.writeheader();wr.writerows(sorted(output,key=lambda x:x['cve']))
    summary=dict(
      calculation='Closed 30-day historical Tuesday observability among 749 later KEV admissions',
      study_start=ORIGIN.isoformat(),study_last_tuesday=LAST.isoformat(),
      membership_rule='0 < (KEV admission date - eligible Tuesday snapshot date) <= 30 calendar days',
      cohort=749,ever_observed=475,never_observed=274,
      observed_in_last_30_days=475,earlier_only_outside_window=0,
      window_observed_not_selected_top1000=434,window_observed_and_selected_top1000=41,
      window_observed_conditional_capture=41/475,full_cohort_capture=41/749,
      noncaptured=708,unselected_ever_observable=434,
      nonselected_with_complete_30_day_tuesday_window=full_noncap,
      nonselected_present_at_every_tuesday_in_complete_window=always_noncap,
      nonselected_present_at_every_tuesday_full_cohort_ratio=always_noncap/434,
      history_rows=n,history_candidate_CVEs=len(rows),recorded_tuesday_population_dates=len(times),
      source_input_files={pathlib.Path(args.event_ledger).name:stream_hash(args.event_ledger),
                          pathlib.Path(args.decision_history).name:stream_hash(args.decision_history)},
      limitations=['Observability concerns exact admitted historical EPSS Tuesday snapshots only.',
                   'At least one in-window observation does not mean presence at every Tuesday or on all intervening dates.',
                   'Top-1000 nonselection can reflect ranking position, capacity, review cadence and the tested source pathway, not a demonstrated causal capacity effect.',
                   'No enterprise exposure, patch completion, or exploitation-onset claim.'])
    (out/'Q1_30Day_Reclassification_Summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('Q1_RECLASSIFICATION_REPLAY: PASS')
    print(json.dumps({k:summary[k] for k in ['cohort','ever_observed','observed_in_last_30_days','earlier_only_outside_window','window_observed_not_selected_top1000','window_observed_and_selected_top1000','nonselected_with_complete_30_day_tuesday_window','nonselected_present_at_every_tuesday_in_complete_window']},sort_keys=True))

if __name__=='__main__':
    main()
