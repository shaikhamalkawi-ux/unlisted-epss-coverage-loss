#!/usr/bin/env python3
"""Positive and tamper-detection tests for Q1 30-day certificate (offline)."""
import csv, gzip, pathlib, tempfile, subprocess, sys, json
HERE=pathlib.Path(__file__).resolve().parents[1]
SCRIPT=HERE/'code'/'reproduce_30day_partition.py'
EVENT=HERE/'inputs'/'reported_public_event_input.csv'
HISTORY=HERE/'inputs'/'event_decision_history.csv.gz'

def run(event,history,dest):
    r=subprocess.run([sys.executable,str(SCRIPT),'--event-ledger',str(event),'--decision-history',str(history),'--out-dir',str(dest)],capture_output=True,text=True)
    return r

def main():
  with tempfile.TemporaryDirectory(prefix='unlisted48_gate_') as t:
    root=pathlib.Path(t)
    x=run(EVENT,HISTORY,root/'clean')
    assert x.returncode==0, x.stderr
    s=json.loads((root/'clean'/'Q1_30Day_Reclassification_Summary.json').read_text())
    assert (s['cohort'],s['ever_observed'],s['observed_in_last_30_days'],s['earlier_only_outside_window'],s['window_observed_not_selected_top1000'],s['window_observed_and_selected_top1000'],s['nonselected_present_at_every_tuesday_in_complete_window']) == (749,475,475,0,434,41,309)
    with EVENT.open(newline='',encoding='utf-8-sig') as f:
        original=list(csv.DictReader(f))
    # One flipped admitted source-observability flag must block, not silently change a count.
    copied=[r.copy() for r in original]
    for row in copied:
        if row['source_observable'].lower()=='true':
            row['source_observable']='False';break
    tamper=root/'flipped_event.csv'
    with tamper.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=copied[0]);w.writeheader();w.writerows(copied)
    assert run(tamper,HISTORY,root/'tamper_flag').returncode!=0
    # Duplicate CVE rows forbidden.
    duplicate=root/'duplicate_event.csv'
    with duplicate.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=original[0]);w.writeheader();w.writerows(original+[original[0]])
    assert run(duplicate,HISTORY,root/'tamper_duplicate').returncode!=0
    # A missing supporting source appearance must not be imputed.
    with gzip.open(HISTORY,'rt',newline='',encoding='utf-8-sig') as f:
       data=list(csv.DictReader(f))
    # Choose a source-visible event with exactly one eligible appearance in its final 30 days.
    appearances={}
    for r in data:
       if 0<int(r['lead_days'])<=30:appearances[r['cve']]=appearances.get(r['cve'],0)+1
    only=next(cve for cve,k in appearances.items() if k==1)
    data=[r for r in data if not (r['cve']==only and 0<int(r['lead_days'])<=30)]
    missing=root/'missing_history.csv.gz'
    with gzip.open(missing,'wt',newline='',encoding='utf-8') as f:
       w=csv.DictWriter(f,fieldnames=data[0]);w.writeheader();w.writerows(data)
    assert run(EVENT,missing,root/'tamper_missing').returncode!=0
    print('UNLISTED48_FAIL_CLOSED_TESTS: 4/4 PASS')

if __name__=='__main__':main()
