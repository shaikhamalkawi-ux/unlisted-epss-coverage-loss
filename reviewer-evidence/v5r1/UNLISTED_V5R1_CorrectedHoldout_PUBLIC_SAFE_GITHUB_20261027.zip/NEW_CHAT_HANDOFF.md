CONTINUE PROJECT 1 UNLISTED / VULN-PU FROM THE FROZEN UNLISTED56R3R1 MANUSCRIPT. DO NOT RESTART.

Date: 2026-10-27. External July–September 2026 V5 temporal holdout remains HOLD: source metadata 15 EPSS + 15 KEV as-of + 1 KEV outcome pinned, original source bytes not read, no external capture results generated.
The V5R1 toolkit corrects an earlier budget-warmup inconsistency and adds both stop and skip affordability rules; synthetic end-to-end and fail-closed tests PASS.
Historical in-sample 171-week 749/475/274/434/41 accounting and experimental budget results remain unchanged and locked. A public GitHub status-only branch was created for reviewer awareness; no full public/archive DOI or independent reviewer download is claimed.
Next required action: complete original source downloads in a network-enabled environment, validate all 31 immutable Git blob locks, rerun the correction, and obtain authorized reviewer-account download/run confirmation for the manuscript-matched archive. No enterprise field or exploitation-onset claim. Preserve author fields blank.
