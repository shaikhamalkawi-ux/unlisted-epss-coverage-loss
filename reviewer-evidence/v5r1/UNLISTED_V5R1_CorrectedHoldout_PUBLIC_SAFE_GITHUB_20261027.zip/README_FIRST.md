# START HERE — UNLISTED R3R1 Experimental Extension (27 October 2026)

**Do not restart the manuscript.** Current manuscript is UNLISTED56R3R1, unchanged. This is a *new empirical robustness audit and pinned source-acquisition toolset*, not UNLISTED57/R4 and not a journal submission.

## Completed (real frozen historic derived data)

The original full scientific source was previously archived and SHA-checked. The new replays use 171 timestamped, SHA-checked **derived EPSS eligible score-ordered candidate arrays**; the new code does not claim independent reconstruction of all 171 files from publisher servers. The 749 later-KEV outcome ledger is frozen.

* L1 41 captures, 2,672 distinct; L4 78 captures, 8,247 distinct, each using 171,000 positions.
* L4 captures more later KEV additions under both `stop on unaffordable` and `skip unaffordable` candidate modes in all 15 published artificial-budget settings.
* Seven alternative fixed weekly capacities all show more L4 captured later KEV additions.
* Exploratory L2–L12 scan shows a non-monotonic capture response. L16+ are **HOLD** due 12,000 candidate prefetch insufficiency.
* Lead-time tradeoff: L4 has lower median earliest warning lead and 25 of the 41 shared captures are selected later.

**No measured analyst effort or prevented attack is claimed.** L4 was previously chosen retrospectively: no prospective optimality inference is allowed.

## V5 external holdout (not executed on actual binary sources)

15 EPSS dated source records and 15 CISA historical as-of source records are located by Git commit/hash metadata. 12 test Tuesdays July 7–Sep 22 follow 3 June warmup Tuesdays. Frozen KEV outcome is the CISA Oct 23 Git commit. Files are from authoritative public GitHub repositories, with immutable commit URLs and Git blob SHA1 checks. This work did **not download the source bytes** in the chat execution and thus has **NO V5 CAPTURE RESULTS**.

- `provenance/V5_SOURCE_LOCK.json` — immutable source IDs and decision clock (Tue 23:59 UTC)
- `code/check_v5_metadata_preflight.py` — metadata-only PASS
- `code/run_v5_pinned_holdout.py` — full SHA-gated network-acquisition/replay, NOT successfully run on real data in this environment
- `tests/test_v5_gate_synthetic.py` — synthetically generated input end-to-end PASS and deliberate tampering fail-closed PASS
- `V5_HOLDOUT_COLAB_RUN.ipynb` — ready for Colab upload of a toolkit ZIP; never treats synthetic results as empirical data

### Two ZIP variants

1. **V5 toolkit / shareable code only:** contains source metadata, algorithms, synthetic test, reports. It does not contain third-party raw data or controlled 171-date CVE-level input panels. Execute it on a network-enabled Colab to perform the real V5 evaluation.
2. **Research New-Chat Transfer / INTERNAL:** contains all of (1), the unchanged quick R3R1 manuscript handoff and the earlier controlled historical rank-panel replay. The controlled input must not be publicly redistributed until licensed.

Full discussion and next gates: `SCIENTIFIC_REPORT.md` and `NEW_CHAT_HANDOFF_READY_TO_COPY.md`.
