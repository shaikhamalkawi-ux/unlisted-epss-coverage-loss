# UNLISTED V5R1 — Corrected External Holdout Toolkit (27 October 2026)

**No new original scientific results**. The out-of-period 12-Tuesday (7 July–22 September 2026) test remains **HOLD** because real original EPSS/KEV files have not been acquired/byte-hash verified here.

This updates the V5 test **protocol**, not UNLISTED56R3R1's locked manuscript.

Scientific correction: modeled-budget scenarios now enforce the *same* budget in the three June 16/23/30 warmup weeks and in the 12 evaluation weeks. Warmup costs do not count in the evaluation's reported work, but warmup selection state **must not pretend to have reviewed more candidates than the budget allowed**. The previously published V5 holdout script did not meet this consistency requirement; its 16 configured cases are superseded by 31 pre-specified settings (one no-budget control, 15 stop-mode and 15 skip-mode budget modes).

## Run locally or in a network-enabled Colab environment

    python code/check_v5_metadata_preflight.py
    python tests/test_v5_gate_synthetic.py
    python -m pip install pandas requests
    python code/run_v5_pinned_holdout.py --manifest provenance/V5_SOURCE_LOCK.json --output results/v5

The last command requests exactly 15 publicly archived gzip EPSS files and 16 CISA KEV JSON blobs at the **immutable Git commit** IDs specified in `provenance/V5_SOURCE_LOCK.json`. A source with missing/wrong bytes or mismatched Git blob hash **cannot yield results**. For an offline-only validation, append `--offline`, supply the expected caches first, and read the failure status.

Github source record: https://github.com/empiricalsec/epss_scores and https://github.com/cisagov/kev-data .

## Tested scope

- Source metadata preflight: PASS, **not raw-source verification**
- Synthetic end-to-end test, both stop/skip and budget-warmup regression: PASS
- Synthetic source tamper rejection: PASS
- Actual external test in this environment: HOLD (source bytes unavailable)
- Full original author-controlled research archive reviewer access: HOLD

Do not call this a prospective field test; the joint decision instant is a **hypothetical Tuesday 23:59:59 UTC**. Actual corporate receipt times are unknown. KEV dateAdded does not identify exploitation onset.

Never enter any external-v5 numeric result in the paper unless real-input acquisition and the full source-gated replay have both passed. Preserve all negative findings.
