# UNLISTED — New Scientific Stress Tests and Pinned V5 Source Gate

**Date:** 27 October 2026  
**Status:** Completed in-sample robustness tests; out-of-period historical holdout computation remains **HOLD**.  
**Active scientific manuscript:** `UNLISTED56R3R1` remains unchanged; no new manuscript version was created.

## 1. Primary findings — verified independent replay

Exact frozen derived candidate source: 171 weekly Tuesday decision panels (2023-03-07 to 2026-06-09), top 12,000 scored and eligible CVEs per date, with cryptographically matched local candidate files and upstream raw-source SHA records. Outcome labels: frozen later CISA KEV admissions, not field-measured exploitation.

- Control policy L1: **41** later-KEV cases, **2,672** distinct chosen CVEs, **171,000** selection positions.
- Policy L4 (exclude prior three Tuesday selections): **78** later-KEV cases, **8,247** distinct chosen CVEs, **171,000** positions.
- No L1-captured CVE was missed by L4 in the full-slot 171-date comparison; 37 distinct additional later-KEV CVEs were captured by L4.
- The earlier 15/15 budget advantage was independently reproduced from SHA-gated derived inputs; a fresh comparison that **skips** rather than **stops** on an unaffordable candidate also shows L4 ahead in 15/15 settings. One configuration improves L4 from 52 to 53; this is a **post-hoc sensitivity**, not a prospective gain.

### Capacity sensitivity (descriptive, post hoc)

| Weekly positions | L1 | L4 |
|---:|---:|---:|
| 50 | 10 | 20 |
| 100 | 14 | 26 |
| 250 | 21 | 40 |
| 500 | 29 | 55 |
| 1,000 | 41 | 78 |
| 1,500 | 54 | 96 |
| 2,000 | 61 | 111 |

The fixed-slot capacity comparison uses the same dated score queues and 30-day later-KEV endpoint, **not equal modeled work across different capacities**.

### L4 memory-length scan (exploratory only)

| Exclusion duration (weekly decisions) | Later-KEV captured | New distinct CVEs | Status |
|---:|---:|---:|---|
| 1 | 41 | 2672 | PASS |
| 2 | 57 | 4827 | PASS |
| 3 | 67 | 6528 | PASS |
| 4 | 78 | 8247 | PASS |
| 5 | 74 | 9829 | PASS |
| 6 | 67 | 11609 | PASS |
| 8 | 59 | 15195 | PASS |
| 12 | 67 | 22219 | PASS |
| 16 | — | — | HOLD_PREFETCH_INSUFFICIENT |
| 24 | — | — | HOLD_PREFETCH_INSUFFICIENT |
| 52 | — | — | HOLD_PREFETCH_INSUFFICIENT |
| 171 | — | — | HOLD_PREFETCH_INSUFFICIENT |

Four-week memory yields the largest observed capture count among the eight evaluable tested durations **on this same retrospective data**. It was already selected using historical outcomes; this does NOT identify a policy optimal outside the study. Exclusions 16 weeks and longer were deliberately **HOLD** after the 12,000-candidate prefetch no longer contained enough eligible candidates to fill the queue; do not interpret partial estimates.

### Captured-case lead-time caveat (important negative result)

| Metric | L1 | L4 |
|---|---:|---:|
| Distinct later-KEV CVEs captured | 41 | 78 |
| Median earliest eligible lead before KEV | 27 days | 20 days |

Among **41 common captured CVEs**, L4 selected 25 with shorter lead, 15 at the same lead, and 1 with longer lead. Median paired L4–L1 lead change was **-7 days**. The **37** unique incremental L4 captures had **14 days** median earliest lead. This reveals a real capture-quantity versus alert-horizon tradeoff. Nonrandom observed strata cannot support a causal analyst-effort or prevention claim.

## 2. V5 temporal holdout — provenance acquired, outcomes NOT computed

Source metadata lock: **15/15** EPSS Git blob IDs (3 warm-up June 16/23/30; 12 weekly decisions July 7–September 22), **15/15** time-constrained CISA KEV Git snapshots, and **1** frozen post-followup CISA October 23 commit. These records exist in public GitHub and have per-file Git blob SHA-1 IDs, expected EPSS byte sizes, file-level commit SHA, and visible committer date. Git commit metadata does not by itself independently authenticate server push time.

**Live source binary acquisition in this execution:** 0/15 raw EPSS files and 0/16 raw KEV JSON versions downloaded and verified. The connected text-oriented GitHub interface rejected binary and oversized JSON. Thus **no holdout captures, p-values, extrapolated improvements, or out-of-time validations were generated**.

### Verifiable source links

- FIRST official EPSS: https://www.first.org/epss/data
- EPSS authoritative history: https://github.com/empiricalsec/epss_scores/tree/main/2026
- CISA official mirror: https://github.com/cisagov/kev-data
- Pinned outcome snapshot commit (23 Oct): https://github.com/cisagov/kev-data/blob/b9c486ef8f3ba0709bb662ae843ffee96953c400/known_exploited_vulnerabilities.json

### Exact replay protocol (implemented, not yet executed on actual external files)

1. Acquire exactly 15 EPSS gzip files from immutable GitHub commit URLs and exactly 15 CISA as-of JSON blobs from immutable repository commits, plus the frozen October 23 outcome file.
2. Stop immediately if any downloaded file fails a pinned Git blob SHA1 or expected compressed byte count; additionally record computed SHA-256.
3. Use a **Tuesday 23:59:59 UTC** hypothetical decision time so both same-Tuesday EPSS and KEV Git repository commits precede the decision. This is not a historically observed corporate feed receipt.
4. Warm up only the selection state on three June Tuesdays; evaluate the 12 July–September Tuesdays; no outcome for warm-up days contributes to holdout capture counts.
5. Exclude CVEs present in the *versioned CISA snapshot admissible as of that decision*; rank EPSS within that date only and keep 12,000 eligible top candidates in score-desc/CVE-asc order.
6. Compare L1 and L4 at 1,000 positions/week without modeled budget, then apply the frozen lambda-grid {0.05, 0.2, 1.0} and weekly modeled-work budgets {50,100,250,500,1000}. Report all scenarios including ties, losses, and negative findings.
7. Endpoint is dated addition to the frozen October 23 KEV catalog within strictly (0,30] days after each decision, not real exploitation onset.

**Synthetic test of complete program:** PASS (16 policy settings and deliberate file-tampering rejection). **Real offline attempt:** expected SOURCE_HOLD due missing binary source; no scientific holdout results produced.

## 3. Claim boundaries / decision

**Scientific interpretation:** On the locked retrospective Tuesday panels, L4 expands the number of subsequently KEV-added CVEs selected, but systematically shortens the warning lead for many common cases. Its historic advantage persists under tested artificial effort-budget settings and an alternative affordability handling rule; this is not proof of better field remediation, causality, attack prevention or equal operational costs.

**No new manuscript version now:** Keep R3R1 frozen. Treat this as a bounded research pilot and source-acquisition kit. Do not promote out-of-time validation, until original EPSS and KEV bytes are acquired, validated, and the pinned holdout code actually executes.

**Other HOLD:** Full daily-versus-weekly same-work comparison across 2023–2026 still lacks independently admitted daily source files and compatible actual decision clocks; v5 twelve-week test does not replace that experiment. Full raw research archive reviewer access and redistribution permissions remain unverified.

## 4. Reproduction

With controlled candidate package extracted to the expected `UNLISTED_Budget_Independent_Check` folder, run `derived_budget_stress_replay.py`, `memory_window_exploration.py` and `paired_lead_audit.py`. Use `UNLISTED_CANDIDATE_ROOT` to change input location and `UNLISTED_STRESS_OUT` for output.

For V5, in a network-enabled Python / Colab environment upload the V5 toolkit, then run:

```bash
python code/check_v5_metadata_preflight.py
python code/run_v5_pinned_holdout.py --manifest provenance/V5_SOURCE_LOCK.json --output results/v5
```

Do not treat `check_v5_metadata_preflight.py` success as raw file validation.

## 5. QA files

- `results/VALIDATION_REPORT.json`: 171-source derived stress replay QA.
- `results/STOP_vs_SKIP_BUDGET_30_RUNS.csv`: sensitivity 30 scenario rows.
- `results/CAPACITY_SENSITIVITY.csv`: seven capacities × two policies.
- `results/EXPLORATORY_MEMORY_WINDOW.csv`: durations and explicit HOLD for insufficient candidate prefetch.
- `results/MATCHED_SHARED_CVE_LEAD_AUDIT.json`: warning-horizon tradeoff.
- `provenance/V5_SOURCE_LOCK.json`: exact source Git commit/blob/time/byte locks.
- `results/V5_METADATA_PREFLIGHT.json`: public metadata inspection only.
- `tests/SYNTHETIC_END_TO_END_QA.json`: synthetic (not real) holdout pipeline PASS.

**Prepared by:** technical assistant as an author-review diagnostic; no human independent peer review, new journal submission, public dataset deposit or field validation is claimed.
