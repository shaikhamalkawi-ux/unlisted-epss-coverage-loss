#!/usr/bin/env python3
"""Offline *metadata-only* source lock audit; never a certificate of downloaded historical EPSS bytes."""
from pathlib import Path
from datetime import datetime,date,timedelta,timezone
import json,re,argparse,hashlib

p=Path(__file__).resolve().parents[1]
spec=json.loads((p/'provenance'/'V5_SOURCE_LOCK.json').read_text())
assert len(spec['dates'])==15 and len(spec['test_dates'])==12
assert len({x['date'] for x in spec['dates']})==15
for i,row in enumerate(spec['dates']):
 d=date.fromisoformat(row['date'])
 assert d==date(2026,6,16)+timedelta(days=7*i)
 assert d.weekday()==1
 assert row['role']==('3-week warmup' if i<3 else 'evaluation')
 assert row['model']=='v2026.06.15'
 for key in ['epss_blob_sha','epss_commit','kev_commit','kev_blob_sha']:
  assert re.fullmatch('[a-f0-9]{40}',row[key]),(i,key)
 for k in ['epss_commit_at','kev_commit_at']:
  t=datetime.fromisoformat(row[k].replace('Z','+00:00'))
  assert t.date()<=d and t<=datetime.combine(d,datetime.max.time(),timezone.utc)
 assert row['epss_bytes']>=2000000
v=spec['outcome_kev'];assert v['commit']=='b9c486ef8f3ba0709bb662ae843ffee96953c400'
assert date.fromisoformat(spec['followup_last_date'])>=date.fromisoformat(spec['test_dates'][-1])+timedelta(days=30)
assert datetime.fromisoformat(v['commit_at'].replace('Z','+00:00')).date()>date.fromisoformat(spec['followup_last_date'])
result={'meta_source_gate':'PASS','actual_raw_source_bytes_fetched_this_turn':0,'EPSS_15_Git_blob_ids_located':15,'KEV_15_asof_blob_ids_located':15,'KEV_frozen_label_blob_id_located':1,'holdout_outcome_replay_executed':False,'no_field_validation':True,'source_lock_sha256':hashlib.sha256((p/'provenance'/'V5_SOURCE_LOCK.json').read_bytes()).hexdigest(),'next_gate':'Retrieve all exact binary blobs, independently match byte counts and Git blob SHA1, then execute same script; any failure => HOLD.'}
(p/'results'/'V5_METADATA_PREFLIGHT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
