#!/usr/bin/env python3
"""Additional *post hoc* robustness audit on frozen derived 171-day score-rank panels.
No use of post-observation labels for policy choices. Not a future temporal holdout.
"""
from __future__ import annotations
from pathlib import Path
from datetime import date,timedelta
import gzip,hashlib,json,csv,collections,statistics,sys,os

SOURCE=Path(os.getenv('UNLISTED_CANDIDATE_ROOT','/mnt/data/UNLISTED_Budget_Independent_Check'))
OUT=Path(os.getenv('UNLISTED_STRESS_OUT','/mnt/data/UNLISTED_R3R1_Policy_StressTest_20261027'))
(OUT/'data').mkdir(parents=True, exist_ok=True)
(OUT/'code').mkdir(parents=True, exist_ok=True)

admissions={r['cve']:date.fromisoformat(r['kev_date']) for r in csv.DictReader((SOURCE/'sources'/'OUTCOME_COHORT_749.csv').open())}
listed={r['cveID']:date.fromisoformat(r['dateAdded']) for r in csv.DictReader((SOURCE/'sources'/'FROZEN_KEV_MINIMAL.csv').open())}
source=list(csv.DictReader((SOURCE/'sources'/'SOURCE_PROVENANCE_171.csv').open()))
hashes=json.loads((SOURCE/'sources'/'INPUT_SHA256_MANIFEST.json').read_text())
assert len(source)==171 and len(admissions)==749
ranked=[]
for ix,r in enumerate(source):
 d=date.fromisoformat(r['date'])
 assert d==date(2023,3,7)+timedelta(days=ix*7)
 fn=SOURCE/'candidates'/f'{d}.json.gz'
 assert hashlib.sha256(fn.read_bytes()).hexdigest()==hashes[str(fn.relative_to(SOURCE))],str(d)
 with gzip.open(fn,'rt') as f: record=json.load(f)
 assert record['raw_source_sha256']==r['raw_sha256'] and record['date']==str(d)
 cv=record['ranked_cves'];assert len(cv)==12000 and len(set(cv))==len(cv)
 assert not any(listed.get(c,date(9999,1,1))<=d for c in cv)
 ranked.append((d,cv))
assert str(ranked[-1][0])=='2026-06-09'

# Proposed changes affect policies only; all outcomes and candidate panels immutable.
def simulate(L=1, capacity=1000, lam=None, budget=None, mode='stop', weekly_allowances=None):
 seen=set();last={};captured={};days=[];max_scan=0
 for step,(d,queue) in enumerate(ranked):
  used=0.;accepted=0;scanned=0;new=0;repeat=0
  allowance=weekly_allowances[step] if weekly_allowances is not None else budget
  for pos,cve in enumerate(queue,1):
   if accepted>=capacity:break
   scanned=pos
   if step-last.get(cve,-100000)<L:continue
   is_new=cve not in seen
   cost=1. if lam is None or is_new else float(lam)
   if allowance is not None and used+cost>allowance+1e-10:
    if mode=='stop':break
    else: continue
   accepted+=1; used+=cost;new+=int(is_new);repeat+=int(not is_new)
   last[cve]=step;seen.add(cve)
   kd=admissions.get(cve)
   if kd is not None and 0<(kd-d).days<=30:
    lead=(kd-d).days
    if cve not in captured or lead>captured[cve]['lead_days']:
     captured[cve]={'date':str(d),'kev_date':str(kd),'lead_days':lead}
  max_scan=max(max_scan,scanned)
  days.append({'date':str(d),'selected':accepted,'new':new,'repeats':repeat,'spent':round(used,8),'scanned':scanned})
 return {'capture':captured,'n':len(captured),'unique':len(seen),'slots':sum(x['selected'] for x in days),'work':round(sum(x['spent'] for x in days),6),'max_scan':max_scan,'days':days}

def row(label,lam,budget,mode,L1,L4,extra=None):
 extras=extra or {}
 lost=len(set(L1['capture'])-set(L4['capture']))
 gained=len(set(L4['capture'])-set(L1['capture']))
 return {'experiment':label,'lambda':lam,'budget':budget,'mode':mode,'L1_captures':L1['n'],'L4_captures':L4['n'], 'gained':gained,'lost':lost,'L1_distinct':L1['unique'],'L4_distinct':L4['unique'],'L1_work':L1['work'],'L4_work':L4['work'],'L1_slots':L1['slots'],'L4_slots':L4['slots'],'L1_max_scan':L1['max_scan'],'L4_max_scan':L4['max_scan'],**extras}

def write_csv(p,rows):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)

r0=simulate(1); r4=simulate(4)
assert (r0['n'],r0['unique'],r0['slots'],r4['n'],r4['unique'],r4['slots'])==(41,2672,171000,78,8247,171000)
assert r0['max_scan']<=12000 and r4['max_scan']<=12000
out=[]
for lam in [.05,.2,1.]:
 for budget in [50,100,250,500,1000]:
  s1=simulate(1,lam=lam,budget=budget,mode='stop')
  s4=simulate(4,lam=lam,budget=budget,mode='stop')
  t1=simulate(1,lam=lam,budget=budget,mode='skip')
  t4=simulate(4,lam=lam,budget=budget,mode='skip')
  # Original results independently re-confirmed against canonical controlled kit.
  refs=list(csv.DictReader((SOURCE/'results'/'FIXED_CEILING_ALL_30_RESULTS.csv').open()))
  for L,r in [(1,s1),(4,s4)]:
   z=next(x for x in refs if float(x['lambda'])==lam and int(x['budget_per_week'])==budget and int(x['policy_L'])==L)
   assert (r['n'],r['unique'],r['slots'])==(int(z['captured_later_kev']),int(z['distinct_first_reviews']),int(z['all_selected_slots']))
  out.append(row('canonical_stop',lam,budget,'stop',s1,s4))
  out.append(row('alternative_skip',lam,budget,'skip',t1,t4))

# Robustness to queue capacity (not a novel primary protocol)
capacities=[]
for cap in [50,100,250,500,1000,1500,2000]:
 for L in [1,4]:
  r=simulate(L,capacity=cap)
  capacities.append({'capacity':cap,'policy_L':L,'later_kev_captures':r['n'],'distinct_cves':r['unique'],'selections':r['slots'],'max_scanned_position':r['max_scan']})

# Year-by-admission & first capture lead histograms
lat=[]; year=[]
for L,r in [(1,r0),(4,r4)]:
 leads=[x['lead_days'] for x in r['capture'].values()]
 lat.append({'policy_L':L,'n_captured':len(leads),'median_lead_days':statistics.median(leads),'mean_lead_days':round(statistics.mean(leads),5),'min_lead_days':min(leads),'max_lead_days':max(leads),'lead_days_ge_7':sum(v>=7 for v in leads),'lead_days_ge_14':sum(v>=14 for v in leads)})
 for y in [2023,2024,2025,2026]:
  subset={k:v for k,v in r['capture'].items() if admissions[k].year==y}
  year.append({'policy_L':L,'KEV_year':y,'captures':len(subset),'median_lead_days':statistics.median([v['lead_days'] for v in subset.values()]) if subset else None})
write_csv(OUT/'data'/'STOP_vs_SKIP_BUDGET_30_RUNS.csv',out)
write_csv(OUT/'data'/'CAPACITY_SENSITIVITY.csv',capacities)
write_csv(OUT/'data'/'FIRST_CAPTURE_LEAD_SUMMARY.csv',lat)
write_csv(OUT/'data'/'ADMISSION_YEAR_CAPTURES.csv',year)
result={
 'status':'PASS', 'source':'171 frozen derived 12000-CVE rank panels; each SHA-256 and 171 upstream raw-source SHA field verified',
 'baseline':{'weekly':[r0['n'],r0['unique'],r0['slots']],'L4':[r4['n'],r4['unique'],r4['slots']]},
 'cross_policy_results':{mode:{'scenarios':sum(r['mode']==mode for r in out),'L4_more':sum(r['mode']==mode and r['L4_captures']>r['L1_captures'] for r in out),'L1_more':sum(r['mode']==mode and r['L4_captures']<r['L1_captures'] for r in out),'ties':sum(r['mode']==mode and r['L4_captures']==r['L1_captures'] for r in out),'any_capture_losses':sum(r['mode']==mode and r['lost']>0 for r in out),'min_gain':min(r['gained'] for r in out if r['mode']==mode),'min_capture_diff':min(r['L4_captures']-r['L1_captures'] for r in out if r['mode']==mode)} for mode in ['stop','skip']},
 'year_capture':year,'lead':lat,'capacity':capacities,
 'max_scan_position':max(r['L4_max_scan'] for r in out),
 'limit':'Posthoc stress test, no measured analyst time, no new daily clock or temporal holdout; source panels derived, not independent raw regeneration in this run.'
}
(OUT/'data'/'VALIDATION_REPORT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
