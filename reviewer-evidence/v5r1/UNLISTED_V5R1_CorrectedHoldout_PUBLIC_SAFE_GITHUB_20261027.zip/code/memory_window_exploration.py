#!/usr/bin/env python3
"""Exploratory memory-length sensitivity ONLY; not a policy optimization or registration."""
import csv,gzip,json,hashlib,os
from pathlib import Path
from datetime import date,timedelta
from statistics import median
root=Path(os.getenv('UNLISTED_CANDIDATE_ROOT','/mnt/data/UNLISTED_Budget_Independent_Check'))
out=Path(__file__).resolve().parents[1]/'results'
manifest=json.loads((root/'sources'/'INPUT_SHA256_MANIFEST.json').read_text())
inputs=list(csv.DictReader((root/'sources'/'SOURCE_PROVENANCE_171.csv').open()))
outcomes={r['cve']:date.fromisoformat(r['kev_date']) for r in csv.DictReader((root/'sources'/'OUTCOME_COHORT_749.csv').open())}
queues=[]
for r in inputs:
 d=date.fromisoformat(r['date']);f=root/'candidates'/f'{d}.json.gz'
 assert hashlib.sha256(f.read_bytes()).hexdigest()==manifest[f'candidates/{d}.json.gz']
 with gzip.open(f,'rt') as io:z=json.load(io)
 assert z['date']==str(d) and z['raw_source_sha256']==r['raw_sha256']
 queues.append((d,z['ranked_cves']))
rows=[]
for L in [1,2,3,4,5,6,8,12,16,24,52,171]:
 last={};seen=set();captures={};selections=0; hold=None
 for ix,(d,cves) in enumerate(queues):
  n=0
  for c in cves:
   if n==1000:break
   if ix-last.get(c,-1000)<L:continue
   n+=1;seen.add(c);last[c]=ix
   outcome=outcomes.get(c)
   if outcome is not None and 0<(outcome-d).days<=30:
    lead=(outcome-d).days
    captures[c]=max(lead,captures.get(c,-1))
  if n < 1000:
   hold={'step':ix,'date':str(d),'filled':n,'rank_prefetch_limit':len(cves)}
   break
  selections+=n
 if hold:
  rows.append({'L_weeks':L,'status':'HOLD_PREFETCH_INSUFFICIENT','later_KEV_captured':None,'distinct_first_selections':None,'repeated_slots':None,'median_lead_days':None,'first_review_share':None,'failure':str(hold)})
 else:
  rows.append({'L_weeks':L,'status':'PASS','later_KEV_captured':len(captures),'distinct_first_selections':len(seen),'repeated_slots':selections-len(seen),'median_lead_days':median(captures.values()) if captures else None,'first_review_share':len(seen)/selections,'failure':''})
with (out/'EXPLORATORY_MEMORY_WINDOW.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print(json.dumps(rows,indent=2))
