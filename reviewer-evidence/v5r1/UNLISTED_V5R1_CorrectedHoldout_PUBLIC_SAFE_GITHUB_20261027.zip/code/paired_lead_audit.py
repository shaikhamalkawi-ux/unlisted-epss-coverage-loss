#!/usr/bin/env python3
"""Within-CVE matched lead diagnostic on frozen 171 derived score-ordered candidate panels."""
import csv,gzip,json,hashlib,os,statistics
from pathlib import Path
from datetime import date
root=Path(os.getenv('UNLISTED_CANDIDATE_ROOT','/mnt/data/UNLISTED_Budget_Independent_Check'));out=Path(__file__).resolve().parents[1]/'results'
refs=list(csv.DictReader((root/'sources'/'SOURCE_PROVENANCE_171.csv').open()))
sha=json.loads((root/'sources'/'INPUT_SHA256_MANIFEST.json').read_text())
target={z['cve']:date.fromisoformat(z['kev_date']) for z in csv.DictReader((root/'sources'/'OUTCOME_COHORT_749.csv').open())}
queues=[]
for r in refs:
 d=date.fromisoformat(r['date']);p=root/'candidates'/f'{d}.json.gz'
 assert hashlib.sha256(p.read_bytes()).hexdigest()==sha[f'candidates/{d}.json.gz']
 with gzip.open(p,'rt') as f:j=json.load(f)
 queues.append((d,j['ranked_cves']))
def policy(L):
 selected={};capt={}
 for i,(d,cs) in enumerate(queues):
  n=0
  for c in cs:
   if n==1000:break
   if i-selected.get(c,-1000)<L:continue
   selected[c]=i;n+=1
   dd=target.get(c)
   if dd and 0<(dd-d).days<=30:
    v=(dd-d).days
    capt[c]=max(v,capt.get(c,-1))
  assert n==1000
 return capt
A,B=policy(1),policy(4);common=set(A)&set(B)
x=[{'cve':c,'L1_lead':A[c],'L4_lead':B[c],'delta_L4_minus_L1':B[c]-A[c]} for c in sorted(common)]
with (out/'MATCHED_SHARED_CVE_LEAD.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=x[0].keys());w.writeheader();w.writerows(x)
r={'common':len(common),'L1_captures':len(A),'L4_captures':len(B),'L4_extra':len(set(B)-set(A)),'L1_lost':len(set(A)-set(B)),'median_paired_delta':statistics.median(q['delta_L4_minus_L1'] for q in x),'earlier':sum(q['delta_L4_minus_L1']>0 for q in x),'later':sum(q['delta_L4_minus_L1']<0 for q in x),'same':sum(q['delta_L4_minus_L1']==0 for q in x),'median_new_L4_cases_lead':statistics.median(B[c] for c in set(B)-set(A))}
(out/'MATCHED_SHARED_CVE_LEAD_AUDIT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
