#!/usr/bin/env python3
"""UNLISTED V5 12-Tuesday externally held-out, gated historical *replay* (NOT field trial).
Usage: python run_v5_pinned_holdout.py --manifest provenance/V5_SOURCE_LOCK.json --output results/v5
       python run_v5_pinned_holdout.py --manifest ... --output ... --offline
Hard-fails before results if any bytes, snapshots, dates, versions or metadata fail.
Requires Python 3.10+, requests, pandas for efficient 15 x 350k-CVE daily score parsing.
No claimed result exists until all checks actually succeed.
"""
from __future__ import annotations
import argparse,csv,gzip,hashlib,io,json,os,re,sys,time
from datetime import date,datetime,timedelta,timezone
from pathlib import Path

try:
 import requests, pandas as pd
except ImportError as e:
 raise SystemExit('HOLD: install requests and pandas. '+str(e))

UTC=timezone.utc

def git_blob_sha(blob:bytes)->str:
 return hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()

def must(cond,msg):
 if not cond: raise RuntimeError('SOURCE_HOLD: '+msg)

def fetch_verified(url,sha,cache,offline=False,expected_size=None):
 fn=Path(cache);fn.parent.mkdir(parents=True,exist_ok=True)
 if fn.exists():
  data=fn.read_bytes()
  if git_blob_sha(data)!=sha or (expected_size and len(data)!=expected_size):
   raise RuntimeError('SOURCE_HOLD: cached file hash/size mismatch '+str(fn))
  return data
 if offline: raise RuntimeError('SOURCE_HOLD: missing offline source '+str(fn))
 err=None
 for retry in range(3):
  try:
   r=requests.get(url,timeout=(15,120));r.raise_for_status()
   data=r.content
   must(git_blob_sha(data)==sha, 'Git blob SHA mismatch '+url)
   if expected_size:must(len(data)==expected_size,'byte length mismatch '+url)
   tmp=fn.with_suffix(fn.suffix+'.pending');tmp.write_bytes(data);tmp.replace(fn)
   return data
  except requests.RequestException as e:
   err=e;time.sleep(2*(retry+1))
 raise RuntimeError('SOURCE_HOLD: network download error '+url+' '+str(err))

def parse_iso(x):
 return datetime.fromisoformat(x.replace('Z','+00:00'))

def check_date_clock(item):
 dd=item['date']
 expected=date.fromisoformat(dd)
 assert expected.weekday()==1,dd
 cutoff=datetime.combine(expected,datetime.max.time(),tzinfo=UTC)
 must(parse_iso(item['epss_commit_at'])<=cutoff,'future EPSS commit at '+dd)
 must(parse_iso(item['kev_commit_at'])<=cutoff,'future KEV commit at '+dd)
 must(parse_iso(item['epss_commit_at'])>=datetime.combine(expected,datetime.min.time(),tzinfo=UTC), 'EPSS file commit not on decision date '+dd)

def score_candidates(raw,entry,blocked,prefetch=12000):
 with gzip.GzipFile(fileobj=io.BytesIO(raw)) as f: head=f.readline().decode('utf8','replace').strip()
 must('model_version:v2026.06.15' in head, 'wrong model version '+entry['date']+' '+head[:100])
 must('score_date:' in head and entry['date'] in head, 'score date mismatch '+entry['date'])
 df=pd.read_csv(io.BytesIO(raw),compression='gzip',comment='#',usecols=['cve','epss'],dtype={'cve':'string','epss':'float64'})
 must(df.cve.notna().all() and df.cve.is_unique, 'missing/duplicated CVE '+entry['date'])
 must(df.epss.notna().all() and df.epss.between(0,1).all(),'score invalid '+entry['date'])
 admissible=df.loc[~df.cve.isin(blocked)].copy()
 must(len(admissible)>=prefetch, 'eligible population too small '+entry['date'])
 # tie discipline: rank is score desc + CVE ASC; nlargest with ties 'all' then stable final cut
 tiepoint=admissible.epss.nlargest(prefetch).iloc[-1]
 pool=admissible.loc[admissible.epss>=tiepoint]
 sorted_=pool.sort_values(['epss','cve'],ascending=[False,True],kind='stable').head(prefetch)
 return sorted_.cve.tolist(), {'scored':len(df),'eligible':len(admissible),'tie_boundary':float(tiepoint),'epss_meta':head}

def parse_kev(raw,day,strict=True):
 o=json.loads(raw.decode('utf8'))
 must(isinstance(o.get('vulnerabilities'),list),'invalid KEV list')
 rows=o['vulnerabilities'];d={}
 for x in rows:
  c=x.get('cveID');ad=x.get('dateAdded')
  must(c and ad and c not in d,'invalid/duplicate KEV')
  d[c]=date.fromisoformat(ad)
 if strict:
  must(all(v<=day for v in d.values()),'as-of KEV source contains post-decision dateAdded '+str(day))
 return d,{'count':len(d),'catalogVersion':o.get('catalogVersion'),'dateReleased':o.get('dateReleased')}

def run_policy(queues,labels,L,cap=1000,lam=None,B=None, scored_dates=None,affordability="stop"):
 must(affordability in ("stop","skip"), "unsupported affordability rule")
 selected_ever=set();last_selected={};captures={};work=0.;unique_by_date=[];audit=[]
 target=set(scored_dates or [d for d,_ in queues])
 for i,(d,cv) in enumerate(queues):
  allow_evaluation=d in target
  total=0.;count=0;new=0;reps=0
  for c in cv:
   if count==cap:break
   if i-last_selected.get(c,-999999)<L:continue
   # Warm-up must obey exactly the same modeled-work budget as the evaluation,
   # or the cheaper "already reviewed" test state is artificially manufactured.
   cost=1. if c not in selected_ever else (lam if lam is not None else 1.)
   if B is not None and total+cost>B+1e-10:
    if affordability=="skip": continue
    break
   count+=1;total+=cost
   new+=int(c not in selected_ever);reps+=int(c in selected_ever)
   last_selected[c]=i;selected_ever.add(c)
   if allow_evaluation:
    k=labels.get(c)
    if k is not None and 0<(k-d).days<=30:
     lead=(k-d).days
     if c not in captures or lead>captures[c]['lead']:
      captures[c]={'cve':c,'select_date':str(d),'dateAdded':str(k),'lead':lead}
  if allow_evaluation:
   work+=total;unique_by_date.append((str(d),new,reps))
   audit.append({'date':str(d),'selected':count,'new':new,'repeat':reps,'work':round(total,7)})
 return {'captures':captures,'n':len(captures),'work':round(work,8),'week':audit,'distinct_in_test':sum(x[1] for x in unique_by_date),'repeats_in_test':sum(x[2] for x in unique_by_date)}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--manifest',required=True);parser.add_argument('--output',required=True);parser.add_argument('--offline',action='store_true'); args=parser.parse_args()
 p=Path(args.manifest).resolve();spec=json.loads(p.read_text());out=Path(args.output).resolve();cache=out.parent/'v5_pinned_cache';
 dates=spec['dates'];must(len(dates)==15,'15=3 warmup + 12 holdout files are required')
 must([z['date'] for z in dates]==[(date(2026,6,16)+timedelta(days=7*i)).isoformat() for i in range(15)],'date list incorrect')
 must(spec['test_dates']==[z['date'] for z in dates[3:]],'evaluation dates not exact')
 done=[];queues=[]; meta=[]
 # Gate all inputs BEFORE policies or labels are evaluated. No partial releases.
 for ix,z in enumerate(dates):
  check_date_clock(z);d=date.fromisoformat(z['date'])
  esha=z['epss_blob_sha'];ec=z['epss_commit'];fname=f'epss_scores-{d}.csv.gz'
  rawurl=f'https://raw.githubusercontent.com/empiricalsec/epss_scores/{ec}/2026/{fname}'
  epss=fetch_verified(rawurl,esha,cache/'epss'/fname,args.offline,z['epss_bytes'])
  kurl=f"https://raw.githubusercontent.com/cisagov/kev-data/{z['kev_commit']}/known_exploited_vulnerabilities.json"
  kevraw=fetch_verified(kurl,z['kev_blob_sha'],cache/'kev'/f"{z['kev_commit']}.json",args.offline)
  listed,kinfo=parse_kev(kevraw,d,strict=True)
  selected,si=score_candidates(epss,z,set(listed))
  queues.append((d,selected));meta.append({'date':str(d),'score_blob':esha,'epss_sha256':hashlib.sha256(epss).hexdigest(),'kev_blob':z['kev_blob_sha'],'kev_sha256':hashlib.sha256(kevraw).hexdigest(),'EPSS_candidates':si['scored'],'eligible':si['eligible'],'asof_kev_count':kinfo['count'],'EPSS_metadata':si['epss_meta']})
  print(f'SOURCE_PASS {ix+1}/15 {d} {si["scored"]} scored, {kinfo["count"]} KEV known',flush=True)
 # Frozen post-maturity outcome, October 23 or later, but not updated after Oct 23.
 final=spec['outcome_kev'];must(parse_iso(final['commit_at']).date()>=date(2026,10,23),'outcome snapshot too early')
 outurl=f"https://raw.githubusercontent.com/cisagov/kev-data/{final['commit']}/known_exploited_vulnerabilities.json"
 finalraw=fetch_verified(outurl,final['blob_sha'],cache/'kev'/f"{final['commit']}.json",args.offline)
 labels,finfo=parse_kev(finalraw,date(2026,10,23),strict=True)
 # Ensure no target is needed later than frozen Oct 23 after maturation Oct22
 last=date(2026,9,22);must(last+timedelta(days=30)<=date(2026,10,22),'followup incomplete')
 tests=set(date.fromisoformat(d) for d in spec['test_dates'])
 capacities=[1000];costs=[None,0.05,0.2,1.0];budgets=[50,100,250,500,1000]
 rows=[];cve_sets={};weeks=[]
 for lam in costs:
  for B in (budgets if lam is not None else [None]):
   for mode in (["stop","skip"] if B is not None else ["no-budget"]):
    rule=mode if B is not None else "stop"
    a=run_policy(queues,labels,1,1000,lam,B,tests,rule)
    b=run_policy(queues,labels,4,1000,lam,B,tests,rule)
    key=f'lam={lam},B={B},affordability={mode}'
    cve_sets[key]={ 'L1':set(a['captures']),'L4':set(b['captures']) }
    rows.append({'setting':key,'lambda':lam,'budget':B,'affordability':mode,'L1_captures':a['n'],'L4_captures':b['n'],'L4_additions':len(cve_sets[key]['L4']-cve_sets[key]['L1']),'L4_losses':len(cve_sets[key]['L1']-cve_sets[key]['L4']),'L1_work':a['work'],'L4_work':b['work'],'L1_new':a['distinct_in_test'],'L4_new':b['distinct_in_test']})
    for policy,record in [('L1',a),('L4',b)]:
     for week in record['week']:weeks.append({'setting':key,'policy':policy,**week})
 # Output only AFTER every source and every policy scenario finishes.
 out.mkdir(parents=True,exist_ok=True)
 def csv_write(fn,lst):
  with (out/fn).open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=lst[0].keys());writer.writeheader();writer.writerows(lst)
 csv_write('LOCKED_V5_SOURCE_CHECKS.csv',meta)
 csv_write('V5_HOLDOUT_POLICY_RESULTS.csv',rows)
 csv_write('V5_WEEKLY_WORK.csv',weeks)
 report={'execution':'PASS','scope':'retrospective EPSS v5 external time-holdout, NOT enterprise prospective','n_holdout_tuesdays':12,'n_source_days':15,'frozen_outcome_kev_version':finfo, 'frozen_outcome_sha256':hashlib.sha256(finalraw).hexdigest(), 'holdout_eligibility':'separately pinned KEV file as of Tuesday 23:59 UTC','warming':'three preceding Tuesday snapshots; cold starting 2026-06-16 only','policies':rows,'limitation':'Git authored timestamps and Git object pinning do not independently certify historical HTTP serving time or enterprise receipt.'}
 (out/'EXECUTION_CERTIFICATE.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'PASS':True,'rows':len(rows),'first':rows[0],'result_dir':str(out)},indent=2))

if __name__=='__main__':main()
