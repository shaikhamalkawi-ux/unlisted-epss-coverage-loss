#!/usr/bin/env python3
"""Deliberately synthetic end-to-end and corruption tests. Never a scientific EPSS/KEV result."""
from pathlib import Path
from datetime import date
import json,gzip,hashlib,subprocess,tempfile,sys

MAIN=Path(__file__).resolve().parents[1]
spec=json.loads((MAIN/'provenance'/'V5_SOURCE_LOCK.json').read_text())
import importlib.util
s=importlib.util.spec_from_file_location('holdout',MAIN/'code'/'run_v5_pinned_holdout.py'); m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
with tempfile.TemporaryDirectory() as t:
 root=Path(t); output=root/'results'/'holdout';cache=output.parent/'v5_pinned_cache';
 base=[f'CVE-2026-{1000000+i}' for i in range(12600)]
 for z in spec['dates']:
  d=z['date'];c='\n'.join(f'{v},{1-i/12600:.6f},0.5' for i,v in enumerate(base))
  payload=gzip.compress((f'#model_version:v2026.06.15,score_date:{d}T12:00:00Z\ncve,epss,percentile\n'+c+'\n').encode(),mtime=0)
  ef=cache/'epss'/f'epss_scores-{d}.csv.gz';ef.parent.mkdir(parents=True,exist_ok=True);ef.write_bytes(payload)
  z['epss_bytes']=len(payload);z['epss_blob_sha']=m.git_blob_sha(payload)
  minimal={'catalogVersion':d,'dateReleased':d+'T21:50:00Z','count':1,'vulnerabilities':[{'cveID':'CVE-2000-0001','dateAdded':'2026-06-01'}]}
  b=json.dumps(minimal,sort_keys=True).encode()
  kf=cache/'kev'/f"{z['kev_commit']}.json";kf.parent.mkdir(parents=True,exist_ok=True);kf.write_bytes(b)
  z['kev_blob_sha']=m.git_blob_sha(b)
 snapshot={'catalogVersion':'2026-10-23','dateReleased':'2026-10-23T21:52:46Z','count':3,'vulnerabilities':[
 {'cveID':'CVE-2000-0001','dateAdded':'2026-06-01'},
 {'cveID':'CVE-2026-1000020','dateAdded':'2026-08-04'},
 {'cveID':'CVE-2026-1001000','dateAdded':'2026-08-18'}]}
 fr=json.dumps(snapshot,sort_keys=True).encode();f=cache/'kev'/f"{spec['outcome_kev']['commit']}.json";f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(fr)
 spec['outcome_kev']['blob_sha']=m.git_blob_sha(fr)
 mp=root/'synthetic_manifest.json';mp.write_text(json.dumps(spec,indent=2))
 cmd=[sys.executable,str(MAIN/'code'/'run_v5_pinned_holdout.py'),'--manifest',str(mp),'--output',str(output),'--offline']
 ok=subprocess.run(cmd,capture_output=True,text=True,timeout=75)
 if ok.returncode!=0:raise RuntimeError('synthetic execution fail\n'+ok.stdout+'\n'+ok.stderr)
 cert=json.loads((output/'EXECUTION_CERTIFICATE.json').read_text())
 assert cert['execution']=='PASS' and len(cert['policies'])==31
 # Tamper one source in a copied cache and confirm the fail-closed gate blocks release.
 first=cache/'epss'/f"epss_scores-{spec['dates'][0]['date']}.csv.gz"
 first.write_bytes(first.read_bytes()+b'X')
 bad=subprocess.run(cmd,capture_output=True,text=True,timeout=15)
 assert bad.returncode!=0 and 'SOURCE_HOLD' in bad.stderr
 # Explicit regression: the warmup must not fill the whole queue when the work budget is one unit.
 d0=date(2026,6,16);d1=date(2026,6,23)
 queues=[(d0,['CVE-2026-1000001','CVE-2026-1000002']),(d1,['CVE-2026-1000002','CVE-2026-1000001'])]
 warmup=m.run_policy(queues,{},1,cap=2,lam=0.2,B=1,scored_dates={d1},affordability='stop')
 assert warmup['week'][0]['selected']==1, warmup
 # Affordability: stop and skip must differ if a 1-unit new CVE precedes a 0.2-unit repeat.
 queues2=[(d0,['CVE-2026-1000001']),(d1,['CVE-2026-1000002','CVE-2026-1000003','CVE-2026-1000001'])]
 stop=m.run_policy(queues2,{},1,cap=3,lam=0.2,B=1.2,scored_dates={d1},affordability='stop')
 skip=m.run_policy(queues2,{},1,cap=3,lam=0.2,B=1.2,scored_dates={d1},affordability='skip')
 assert stop['week'][0]['selected']==1 and skip['week'][0]['selected']==2, (stop,skip)
 print(json.dumps({'SYNTHETIC_ONLY':True,'end_to_end':'PASS','policy_cases':len(cert['policies']),'tamper_detection':'PASS','failure_code':bad.returncode},indent=2))
